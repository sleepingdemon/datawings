package com.jeesite.modules.plm.entity;

import javax.validation.Valid;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Size;
import java.util.List;
import com.jeesite.common.collect.ListUtils;

import com.jeesite.common.entity.DataEntity;
import com.jeesite.common.mybatis.annotation.Column;
import com.jeesite.common.mybatis.annotation.Table;
import com.jeesite.common.mybatis.mapper.query.QueryType;

/**
 * 零部件Entity
 * @author QianGan
 * @version 2024-04-30
 */
@Table(name="item", alias="a", label="零部件信息", columns={
		@Column(name="id", attrName="id", label="编号", isPK=true),
		@Column(name="part_number", attrName="partNumber", label="零部件编号"),
		@Column(includeEntity=DataEntity.class),
	}, orderBy="a.update_date DESC"
)
public class Item extends DataEntity<Item> {
	
	private static final long serialVersionUID = 1L;
	private String partNumber;		// 零部件编号
	private List<ItemRevision> itemRevisionList = ListUtils.newArrayList();		// 子表列表

	public Item() {
		this(null);
	}
	
	public Item(String id){
		super(id);
	}
	
	@NotBlank(message="零部件编号不能为空")
	@Size(min=0, max=128, message="零部件编号长度不能超过 128 个字符")
	public String getPartNumber() {
		return partNumber;
	}

	public void setPartNumber(String partNumber) {
		this.partNumber = partNumber;
	}
	
	@Valid
	public List<ItemRevision> getItemRevisionList() {
		return itemRevisionList;
	}

	public void setItemRevisionList(List<ItemRevision> itemRevisionList) {
		this.itemRevisionList = itemRevisionList;
	}
	
}