package com.jeesite.modules.plm.dao;

import com.jeesite.common.dao.CrudDao;
import com.jeesite.common.mybatis.annotation.MyBatisDao;
import com.jeesite.modules.plm.entity.ItemRevision;

/**
 * 零部件DAO接口
 * @author QianGan
 * @version 2024-04-30
 */
@MyBatisDao
public interface ItemRevisionDao extends CrudDao<ItemRevision> {
	
}