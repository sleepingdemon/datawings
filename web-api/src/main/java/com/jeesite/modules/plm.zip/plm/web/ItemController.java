package com.jeesite.modules.plm.web;

import java.util.List;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.jeesite.common.config.Global;
import com.jeesite.common.entity.Page;
import com.jeesite.common.web.BaseController;
import com.jeesite.modules.plm.entity.Item;
import com.jeesite.modules.plm.entity.ItemRevision;
import com.jeesite.modules.plm.service.ItemService;

/**
 * 零部件Controller
 * @author QianGan
 * @version 2024-04-30
 */
@Controller
@RequestMapping(value = "${adminPath}/plm/item")
public class ItemController extends BaseController {

	@Autowired
	private ItemService itemService;
	
	/**
	 * 获取数据
	 */
	@ModelAttribute
	public Item get(String id, boolean isNewRecord) {
		return itemService.get(id, isNewRecord);
	}
	
	/**
	 * 查询列表
	 */
	@RequiresPermissions("plm:item:view")
	@RequestMapping(value = {"list", ""})
	public String list(Item item, Model model) {
		model.addAttribute("item", item);
		return "modules/plm/itemList";
	}
	
	/**
	 * 查询列表数据
	 */
	@RequiresPermissions("plm:item:view")
	@RequestMapping(value = "listData")
	@ResponseBody
	public Page<Item> listData(Item item, HttpServletRequest request, HttpServletResponse response) {
		item.setPage(new Page<>(request, response));
		Page<Item> page = itemService.findPage(item);
		return page;
	}
	
	/**
	 * 查询子表数据
	 */
	@RequiresPermissions("plm:item:view")
	@RequestMapping(value = "itemRevisionListData")
	@ResponseBody
	public Page<ItemRevision> subListData(ItemRevision itemRevision, HttpServletRequest request, HttpServletResponse response) {
		itemRevision.setPage(new Page<>(request, response));
		Page<ItemRevision> page = itemService.findSubPage(itemRevision);
		return page;
	}

	/**
	 * 查看编辑表单
	 */
	@RequiresPermissions("plm:item:view")
	@RequestMapping(value = "form")
	public String form(Item item, Model model) {
		model.addAttribute("item", item);
		return "modules/plm/itemForm";
	}

	/**
	 * 保存数据
	 */
	@RequiresPermissions("plm:item:edit")
	@PostMapping(value = "save")
	@ResponseBody
	public String save(@Validated Item item) {
		itemService.save(item);
		return renderResult(Global.TRUE, text("保存零部件成功！"));
	}
	
	/**
	 * 删除数据
	 */
	@RequiresPermissions("plm:item:edit")
	@RequestMapping(value = "delete")
	@ResponseBody
	public String delete(Item item) {
		itemService.delete(item);
		return renderResult(Global.TRUE, text("删除零部件成功！"));
	}
	
}