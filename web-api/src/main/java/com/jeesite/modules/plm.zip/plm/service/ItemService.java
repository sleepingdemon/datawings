package com.jeesite.modules.plm.service;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.jeesite.common.entity.Page;
import com.jeesite.common.service.CrudService;
import com.jeesite.modules.plm.entity.Item;
import com.jeesite.modules.plm.dao.ItemDao;
import com.jeesite.modules.plm.entity.ItemRevision;
import com.jeesite.modules.plm.dao.ItemRevisionDao;

/**
 * 零部件Service
 * @author QianGan
 * @version 2024-04-30
 */
@Service
public class ItemService extends CrudService<ItemDao, Item> {
	
	@Autowired
	private ItemRevisionDao itemRevisionDao;
	
	/**
	 * 获取单条数据
	 * @param item
	 * @return
	 */
	@Override
	public Item get(Item item) {
		Item entity = super.get(item);
		if (entity != null){
			ItemRevision itemRevision = new ItemRevision(entity);
			itemRevision.setStatus(ItemRevision.STATUS_NORMAL);
			entity.setItemRevisionList(itemRevisionDao.findList(itemRevision));
		}
		return entity;
	}
	
	/**
	 * 查询分页数据
	 * @param item 查询条件
	 * @param item page 分页对象
	 * @return
	 */
	@Override
	public Page<Item> findPage(Item item) {
		return super.findPage(item);
	}
	
	/**
	 * 查询列表数据
	 * @param item
	 * @return
	 */
	@Override
	public List<Item> findList(Item item) {
		return super.findList(item);
	}
	
	/**
	 * 查询子表分页数据
	 * @param itemRevision
	 * @param itemRevision page 分页对象
	 * @return
	 */
	public Page<ItemRevision> findSubPage(ItemRevision itemRevision) {
		Page<ItemRevision> page = itemRevision.getPage();
		page.setList(itemRevisionDao.findList(itemRevision));
		return page;
	}
	
	/**
	 * 保存数据（插入或更新）
	 * @param item
	 */
	@Override
	@Transactional
	public void save(Item item) {
		super.save(item);
		// 保存 Item子表
		for (ItemRevision itemRevision : item.getItemRevisionList()){
			if (!ItemRevision.STATUS_DELETE.equals(itemRevision.getStatus())){
				itemRevision.setItem(item);
				if (itemRevision.getIsNewRecord()){
					itemRevisionDao.insert(itemRevision);
				}else{
					itemRevisionDao.update(itemRevision);
				}
			}else{
				itemRevisionDao.delete(itemRevision);
			}
		}
	}
	
	/**
	 * 更新状态
	 * @param item
	 */
	@Override
	@Transactional
	public void updateStatus(Item item) {
		super.updateStatus(item);
	}
	
	/**
	 * 删除数据
	 * @param item
	 */
	@Override
	@Transactional
	public void delete(Item item) {
		super.delete(item);
		ItemRevision itemRevision = new ItemRevision();
		itemRevision.setItem(item);
		itemRevisionDao.deleteByEntity(itemRevision);
	}
	
}