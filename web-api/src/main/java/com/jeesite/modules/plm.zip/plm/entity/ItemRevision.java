package com.jeesite.modules.plm.entity;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Size;

import com.jeesite.common.entity.DataEntity;
import com.jeesite.common.mybatis.annotation.Column;
import com.jeesite.common.mybatis.annotation.Table;
import com.jeesite.common.mybatis.mapper.query.QueryType;

/**
 * 零部件Entity
 * @author QianGan
 * @version 2024-04-30
 */
@Table(name="item_revision", alias="a", label="零部件信息", columns={
		@Column(name="id", attrName="id", label="编号", isPK=true),
		@Column(name="revision_id", attrName="revisionId", label="版本号"),
		@Column(name="name", attrName="name", label="名称", queryType=QueryType.LIKE),
		@Column(name="item", attrName="item.id", label="零部件"),
		@Column(includeEntity=DataEntity.class),
	}, orderBy="a.create_date ASC"
)
public class ItemRevision extends DataEntity<ItemRevision> {
	
	private static final long serialVersionUID = 1L;
	private String revisionId;		// 版本号
	private String name;		// 名称
	private Item item;		// 零部件 父类

	public ItemRevision() {
		this(null);
	}

	public ItemRevision(Item item){
		this.item = item;
	}
	
	@NotBlank(message="版本号不能为空")
	@Size(min=0, max=128, message="版本号长度不能超过 128 个字符")
	public String getRevisionId() {
		return revisionId;
	}

	public void setRevisionId(String revisionId) {
		this.revisionId = revisionId;
	}
	
	@NotBlank(message="名称不能为空")
	@Size(min=0, max=512, message="名称长度不能超过 512 个字符")
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
	
	public Item getItem() {
		return item;
	}

	public void setItem(Item item) {
		this.item = item;
	}
	
}